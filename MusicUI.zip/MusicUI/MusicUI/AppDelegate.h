//
//  AppDelegate.h
//  MusicUI
//
//  Created by jiangqianghua on 17/7/25.
//  Copyright © 2017年 jiangqianghua. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

