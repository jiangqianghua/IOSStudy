//
//  ViewController.h
//  MusicUI
//
//  Created by jiangqianghua on 17/7/25.
//  Copyright © 2017年 jiangqianghua. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    NSArray *tabArray  ;
}
@end

